$('.slickSlider').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 3
});